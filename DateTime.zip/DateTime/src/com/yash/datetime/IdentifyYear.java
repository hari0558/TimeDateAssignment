package com.yash.datetime;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.ZoneId;
import java.time.ZonedDateTime;



public class IdentifyYear {

	public static void main(String[] args) {
		

		
		/*
		 2.  Identify number of Years from 15th August,1947 till date.
		 */
		LocalDate localDate=LocalDate.now();//("17-6-1997");
		LocalDate afterYer=localDate.plusYears(1);
		System.out.println("date of birth after one year is:"+afterYer);
		System.out.println("localDate is:->"+localDate);
		LocalDate Aug151947=LocalDate.of(1947, 8, 15);
		Period periodBwYears=Period.between(localDate.now(),Aug151947 );
		System.out.println("\nperiod between two years is:"+periodBwYears);
		/*
		3. Get current time for following cities,

		   1.London
		   2.Berlin
		   3.New York
		   4.Mumbai
		   5.Singapore
		   */
		ZoneId zoneId=ZoneId.of("Europe/London");
		
		ZoneId zoneId1=ZoneId.of("Europe/Berlin");
		ZoneId zoneId2=ZoneId.of("America/New_York");
		ZoneId zoneId3=ZoneId.of("Asia/Singapore");
		ZoneId zoneId4=ZoneId.of("Asia/Kolkata");
		
		
		LocalDateTime localDateTime=LocalDateTime.now();
		ZonedDateTime zoneDateTime=ZonedDateTime.of(localDateTime, zoneId);
		System.out.println("\nEurope/landon date and time is:->"+zoneDateTime);
		ZonedDateTime zoneDateTime1=ZonedDateTime.of(localDateTime, zoneId1);
		System.out.println("\nEurope/berlin date and time is:->"+zoneDateTime1);
		ZonedDateTime zoneDateTime2=ZonedDateTime.of(localDateTime, zoneId2);
		System.out.println("\nAmerica/New_york date and time is:->"+zoneDateTime2);
		ZonedDateTime zoneDateTime3=ZonedDateTime.of(localDateTime, zoneId3);
		System.out.println("\nAsia/Singapore date and time is:->"+zoneDateTime3);
		ZonedDateTime zoneDateTime4=ZonedDateTime.of(localDateTime, zoneId4);
		System.out.println("\nAsia/Kolkata/Mumboi date and time is:->"+zoneDateTime4);
		
		
		
	}

}
